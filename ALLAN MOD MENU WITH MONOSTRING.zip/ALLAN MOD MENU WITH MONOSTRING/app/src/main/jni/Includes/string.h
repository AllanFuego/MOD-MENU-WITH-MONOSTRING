#include "Utils.h" //(Don't really need this if you're using LGL's or made your own.)
#include <Substrate/SubstrateHook.h>

typedef struct _monoString {
    void *klass;
    void *monitor;
    int length;
    char chars[1];

    int getLength() {
        return length;
    }

    char *getChars() {
        return chars;
    }
} monoString;

monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getRealOffset(0x8D1520);

    return String_CreateString(NULL, str);
}
