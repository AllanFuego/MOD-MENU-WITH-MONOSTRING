# Android Mod Menu with color animation
I did this for fun since RAUNAK MODS begged me to make it, but he is nice now and helped me out with LinearLayout animation, and I got the idea to do rainbow animation by myself.

Animation will not be added to the main project, and this will not be maintained much. But feel free to go through the code and copy that into your project

There are 2 animations, animation layout can be switched if you set ANIMATION_LAYOUT. 0 = Rainbow animation, 1 = Octowolve's 2 colors animation

This project is based on mod menu 2.8 https://github.com/LGLTeam/Android-Mod-Menu

Text animation based on Titanic project https://github.com/romainpiel/Titanic

Menu linearlayout animation is based on GradientDrawable. https://developer.android.com/reference/android/graphics/drawable/GradientDrawable

`ValueAnimator.ofArgb` is only for Android 5.0 and above

Octowolve's 2 colors animation works on 4.4 https://github.com/Octowolve/Hooking-Template-With-Mod-Menu

Have fun :))

![](demo.gif)

![](demo2.gif)